package com.example.piratechest;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class AnimationOverlay {

    private static final int TOTAL_FRAMES = 50;
    private static final int TICKS_PER_FRAME = 1; // roughly 20fps
    private static final Identifier[] FRAMES = new Identifier[TOTAL_FRAMES];

    static {
        for (int i = 0; i < TOTAL_FRAMES; i++) {
            String name = String.format("textures/gui/animation/%03d.png", i + 1);
            FRAMES[i] = new Identifier("piratechest", name);
        }
    }

    private boolean playing = false;
    private int currentFrame = 0;
    private int ticks = 0;
    private static final int HOLD_LAST_FRAMES = 25; // hold the final frame a bit
    private static final int FADE_OUT_TICKS = 15;

    public void start() {
        this.playing = true;
        this.currentFrame = 0;
        this.ticks = 0;
    }

    public boolean isPlaying() {
        return playing;
    }

    public void tick() {
        if (!playing) return;

        ticks++;

        int frameIndex = ticks / TICKS_PER_FRAME;
        if (frameIndex < TOTAL_FRAMES) {
            currentFrame = frameIndex;
        } else {
            currentFrame = TOTAL_FRAMES - 1;
            // After holding, stop
            if (ticks > TOTAL_FRAMES * TICKS_PER_FRAME + HOLD_LAST_FRAMES + FADE_OUT_TICKS) {
                playing = false;
            }
        }
    }

    public void render(DrawContext context, float tickDelta) {
        if (!playing) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.getWindow() == null) return;

        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();

        // Original texture size
        int texW = 512;
        int texH = 256;

        // Scale to look good on most resolutions
        float scale = Math.min(screenWidth / 700f, screenHeight / 400f);
        scale = MathHelper.clamp(scale, 0.7f, 1.6f);

        int drawW = (int) (texW * scale);
        int drawH = (int) (texH * scale);

        int x = (screenWidth - drawW) / 2;
        int y = (screenHeight - drawH) / 2 - (int)(30 * scale);

        // Calculate alpha for fade-in / fade-out
        float alpha = 1.0f;
        int animLength = TOTAL_FRAMES * TICKS_PER_FRAME;
        if (ticks < 4) {
            alpha = ticks / 4.0f;
        } else if (ticks > animLength + HOLD_LAST_FRAMES) {
            float fadeProgress = (ticks - animLength - HOLD_LAST_FRAMES) / (float) FADE_OUT_TICKS;
            alpha = 1.0f - MathHelper.clamp(fadeProgress, 0f, 1f);
        }

        if (alpha <= 0.01f) return;

        Identifier texture = FRAMES[MathHelper.clamp(currentFrame, 0, TOTAL_FRAMES - 1)];

        // Draw with alpha
        context.setShaderColor(1f, 1f, 1f, alpha);
        context.drawTexture(texture, x, y, 0, 0, drawW, drawH, drawW, drawH);
        context.setShaderColor(1f, 1f, 1f, 1f);
    }
}
