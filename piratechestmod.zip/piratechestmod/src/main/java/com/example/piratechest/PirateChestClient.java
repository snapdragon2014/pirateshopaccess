package com.example.piratechest;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class PirateChestClient implements ClientModInitializer {

    public static final Identifier PIRATE_ACCESS_SOUND_ID = new Identifier("piratechest", "pirate_access");
    public static final SoundEvent PIRATE_ACCESS_SOUND = SoundEvent.of(PIRATE_ACCESS_SOUND_ID);

    public static AnimationOverlay animationOverlay = new AnimationOverlay();

    @Override
    public void onInitializeClient() {
        // Register the sound
        Registry.register(Registries.SOUND_EVENT, PIRATE_ACCESS_SOUND_ID, PIRATE_ACCESS_SOUND);

        // Listen for screen open - chests, barrels, shulkers etc.
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof GenericContainerScreen || 
                (screen instanceof HandledScreen && screen.getClass().getSimpleName().contains("Chest"))) {
                // Trigger only if not already playing
                if (!animationOverlay.isPlaying()) {
                    playAnimationAndSound(client);
                }
            }
        });

        // Tick animation
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            animationOverlay.tick();
        });

        // Render overlay on top of everything
        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            animationOverlay.render(drawContext, tickDelta);
        });
    }

    private void playAnimationAndSound(MinecraftClient client) {
        client.getSoundManager().play(PositionedSoundInstance.master(PIRATE_ACCESS_SOUND, 1.0f, 1.0f));
        animationOverlay.start();
    }
}
