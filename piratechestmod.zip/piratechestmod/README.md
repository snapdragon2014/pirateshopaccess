# Pirate Chest Animation Mod (Client-Side)

Minecraft 1.20.1 Fabric mod.

Her sandık (chest), varil, shulker box vs. açtığında Fortnite Pirate Shop Access animasyonunu ve sesini oynatır.

## Animasyon Hakkında

Videodaki animasyonun başlangıcı:
- Küçük eğik kahverengi/altın kare (token)
- Hızla büyüyüp dönerek altın Fortnite coin'e dönüşüyor
- Sarı halka + ışın efektleri
- "YOU FOUND PIRATE SHOP ACCESS" yazısı + yanlardaki kırmızı-sarı banner'lar beliriyor
- Arka planda büyük soluk "PIRATE SHOP ACCESS" yazısı

Bitişi:
- Animasyon son frame'de bir süre duruyor
- Sonra yavaşça fade out yapıyor

## Kurulum

1. Fabric Loader 1.20.1 + Fabric API kurulu olsun.
2. Bu modun jar'ını `mods` klasörüne at.
3. Oyunu aç, herhangi bir sandık aç → animasyon + ses gelir.

## Kaynak Koddan Derleme

```bash
./gradlew build
```

Çıkan jar: `build/libs/piratechest-1.0.0.jar`

## Notlar

- Tamamen client-side. Sunucuya gerek yok, multiplayer'da da çalışır.
- Animasyon frame'leri videodan chroma-key ile çıkarıldı (yeşil ekran temizlendi).
- Ses orijinal videodaki ses.
- Performans için 50 frame @ ~20fps kullanıldı.

Geliştirici: Grok
