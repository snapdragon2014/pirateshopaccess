package com.example.piratechest;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class AnimationOverlay {

    private static final int TOTAL_FRAMES = 57;
    private static final int TICKS_PER_FRAME = 1; // ~20 fps
    private static final Identifier[] FRAMES = new Identifier[TOTAL_FRAMES];

    static {
        for (int i = 0; i < TOTAL_FRAMES; i++) {
            // files are named 001.png ... 057.png
            String name = String.format("textures/gui/animation/%03d.png", i + 1);
            FRAMES[i] = new Identifier("piratechest", name);
        }
    }

    private boolean playing = false;
    private int currentFrame = 0;
    private int ticks = 0;

    // Timing
    private static final int HOLD_LAST = 30;   // last frame hold
    private static final int FADE_OUT   = 18;  // fade out duration

    public void start() {
        this.playing = true;
        this.currentFrame = 0;
        this.ticks = 0;
    }

    public boolean isPlaying() {
        return playing;
    }

    public void tick() {
        if (!playing) return;

        ticks++;

        int frameIndex = ticks / TICKS_PER_FRAME;
        if (frameIndex < TOTAL_FRAMES) {
            currentFrame = frameIndex;
        } else {
            currentFrame = TOTAL_FRAMES - 1;
            if (ticks > TOTAL_FRAMES * TICKS_PER_FRAME + HOLD_LAST + FADE_OUT) {
                playing = false;
            }
        }
    }

    public void render(DrawContext context, float tickDelta) {
        if (!playing) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.getWindow() == null) return;

        int sw = client.getWindow().getScaledWidth();
        int sh = client.getWindow().getScaledHeight();

        // Texture is 640x320
        int texW = 640;
        int texH = 320;

        // Scale so it looks big and impactful
        float scale = Math.min(sw / 780f, sh / 420f);
        scale = MathHelper.clamp(scale, 0.75f, 1.7f);

        int drawW = (int) (texW * scale);
        int drawH = (int) (texH * scale);

        int x = (sw - drawW) / 2;
        int y = (sh - drawH) / 2 - (int)(20 * scale);

        // Fade in / fade out
        float alpha = 1.0f;
        int animEnd = TOTAL_FRAMES * TICKS_PER_FRAME;

        if (ticks < 5) {
            alpha = ticks / 5.0f;
        } else if (ticks > animEnd + HOLD_LAST) {
            float t = (ticks - animEnd - HOLD_LAST) / (float) FADE_OUT;
            alpha = 1.0f - MathHelper.clamp(t, 0f, 1f);
        }

        if (alpha < 0.02f) return;

        Identifier tex = FRAMES[MathHelper.clamp(currentFrame, 0, TOTAL_FRAMES - 1)];

        context.setShaderColor(1f, 1f, 1f, alpha);
        context.drawTexture(tex, x, y, 0, 0, drawW, drawH, drawW, drawH);
        context.setShaderColor(1f, 1f, 1f, 1f);
    }
}
