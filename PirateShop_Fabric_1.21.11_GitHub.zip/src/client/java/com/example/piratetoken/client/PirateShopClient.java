package com.example.piratetoken.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.inventory.ChestMenu;

public class PirateShopClient implements ClientModInitializer {

    private static final String MODID = "piratetoken";
    private static final Identifier BANNER = Identifier.fromNamespaceAndPath(MODID, "textures/gui/pirate_shop_access.png");
    private static final Identifier EMBLEM = Identifier.fromNamespaceAndPath(MODID, "textures/gui/emblem.png");
    private static final SoundEvent SHOP_SOUND = SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath(MODID, "shop"));

    private static final int BW = 96, BH = 16;   // banner texture boyutu
    private static final int EM = 64;            // amblem texture boyutu
    private static final float OPEN_MS = 4200f;
    private static final float CLOSE_MS = 700f;

    private static long startTime = 0;
    private static int mode = 0;                 // 0 yok, 1 acilis, 2 kapanis
    private static Screen animScreen = null;

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof AbstractContainerScreen<?> acs && acs.getMenu() instanceof ChestMenu) {
                if (screen != animScreen) {          // sadece ilk acilista baslat (yeniden boyutlandirmada degil)
                    animScreen = screen;
                    mode = 1;
                    startTime = System.currentTimeMillis();
                    Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SHOP_SOUND, 1.0F, 1.0F));
                }
                ScreenEvents.afterRender(screen).register((s, graphics, mouseX, mouseY, tickDelta) -> draw(graphics));
                ScreenEvents.remove(screen).register(s -> {
                    if (s == animScreen) {
                        animScreen = null;
                        mode = 2;
                        startTime = System.currentTimeMillis();
                    }
                });
            }
        });

        // sandik kapandiktan sonra oyun ekraninda
        HudElementRegistry.attachElementAfter(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MODID, "animation"),
                (graphics, tracker) -> {
                    if (Minecraft.getInstance().screen == null) draw(graphics);
                });
    }

    private static float easeOut(float u) { float k = 1f - u; return 1f - k * k * k; }
    private static float easeIn(float u)  { return u * u * u; }

    private static void draw(GuiGraphics g) {
        if (mode == 0) return;

        float total = (mode == 1) ? OPEN_MS : CLOSE_MS;
        float elapsed = System.currentTimeMillis() - startTime;
        if (elapsed > total) { mode = 0; return; }
        float t = elapsed / total;

        int width = g.guiWidth();
        int height = g.guiHeight();
        float cx = width / 2f;

        // kucuk ekranlarda sandigi kapatmasin diye kucult
        float guiTop = (height - 222) / 2f;
        float fit = Math.max(0.5f, Math.min(1f, guiTop / 80f));

        float emSize = 40f * fit;
        float emY = 28f * fit;
        float bannerY = emY + emSize / 2f + 6f * fit + 12f * fit;
        float dist = cx + BW;

        float emScale, emAngle, bx;
        boolean bannerVisible = true;

        if (mode == 1) {
            // amblem: donerek buyuyerek gelir, yavasca doner, kuculup cikar
            if (t < 0.10f) {
                float u = easeOut(t / 0.10f);
                emScale = u * 1.3f; emAngle = 360f * u;
            } else if (t < 0.17f) {
                emScale = 1.3f - 0.3f * ((t - 0.10f) / 0.07f); emAngle = 0f;
            } else if (t < 0.50f) {
                emScale = 1f; emAngle = (t - 0.17f) * 40f;
            } else if (t < 0.62f) {
                float u = easeIn((t - 0.50f) / 0.12f);
                emScale = 1f - u; emAngle = (t - 0.17f) * 40f + 360f * u;
            } else {
                emScale = 0f; emAngle = 0f;
            }

            // banner: soldan kayarak gelir, saga gecip gider, sagdan geri gelir, saga cikar
            if (t < 0.10f)      { bx = -dist; bannerVisible = false; }
            else if (t < 0.22f) bx = -dist * (1f - easeOut((t - 0.10f) / 0.12f));
            else if (t < 0.45f) bx = 0f;
            else if (t < 0.60f) bx = dist * easeIn((t - 0.45f) / 0.15f);
            else if (t < 0.75f) bx = dist * (1f - easeOut((t - 0.60f) / 0.15f));
            else if (t < 0.88f) bx = 0f;
            else                bx = dist * easeIn((t - 0.88f) / 0.12f);
        } else {
            float u = easeIn(t);
            emScale = 1f - u; emAngle = 360f * u;
            bx = dist * u;
        }

        // amblem
        if (emScale > 0.01f) {
            g.pose().pushMatrix();
            g.pose().translate(cx, emY);
            g.pose().rotate((float) Math.toRadians(emAngle));
            float s = (emSize / EM) * emScale;
            g.pose().scale(s, s);
            g.blit(RenderPipelines.GUI_TEXTURED, EMBLEM, -EM / 2, -EM / 2, 0f, 0f, EM, EM, EM, EM);
            g.pose().popMatrix();
        }

        // banner
        if (bannerVisible) {
            g.pose().pushMatrix();
            g.pose().translate(cx + bx, bannerY);
            g.pose().scale(1.5f * fit, 1.5f * fit);
            g.blit(RenderPipelines.GUI_TEXTURED, BANNER, -BW / 2, -BH / 2, 0f, 0f, BW, BH, BW, BH);
            g.pose().popMatrix();
        }
    }
}
