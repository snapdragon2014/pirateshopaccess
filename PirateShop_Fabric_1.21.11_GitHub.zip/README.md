# Pirate Shop Access (Fabric 1.21.11, client-side)
Sandik acilinca pixel amblem + PIRATE SHOP ACCESS animasyonu ve ses.
Derleme: Actions -> son calisma -> Artifacts -> PirateShop-Fabric-1.21.11 (icindeki "-sources" olmayan jar).
